<!-- filename: EditDog.php
    Author: Caleb Sutton -->
    <?php
    session_start();
    error_reporting(E_ALL);
ini_set('display_errors', '1');

if(!isset($_SESSION['username'])){
    header('Location: notloggedin.php');
}
    $options = '';
    $doglist = '';
    $username = $_SESSION['username'];
    if ($username != 'admin'){
        header("Location: Welcome.php");
    }

        try {
            $pdo = new PDO("mysql:host=localhost;port=8889;dbname=project", "root", "root");
            // set the PDO error mode to exception
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            //echo "Connected successfully";
          } 
          catch(PDOException $e) {
            echo "Connection failed: " . $e->getMessage();
          }
          if(isset($_POST['submit'])){
            $dog = $_POST['User'];
            if(isset($_POST['newname']) && $_POST['newname'] != ''){
                $newname = $_POST['newName'];
                $query = $pdo->prepare('UPDATE dogs
                SET Dog_Name = "'.$newname.'"
                WHERE Dog_Name = "'.$dog.'";');
                $query->execute();
            }
            if(isset($_POST['age']) && $_POST['age'] != ''){
                $newage = $_POST['age'];
                $query = $pdo->prepare('UPDATE dogs
                SET Dog_Age = "'.$newage.'"
                WHERE Dog_Name = "'.$dog.'" OR Dog_Name = "'.$newname.'";');
                $query->execute();
            }
            if(isset($_POST['Breed']) && $_POST['Breed'] != ''){
                $newbreed = $_POST['Breed'];
                $query = $pdo->prepare('UPDATE dogs
                SET Dog_Breed = "'.$newbreed.'"
                WHERE Dog_Name = "'.$dog.'" OR Dog_Name = "'.$newname.'";');
                $query->execute();
            }
            if(isset($_POST['favorite']) && $_POST['favorite'] != ''){
                $favorite = $_POST['favorite'];
                $query = $pdo->prepare('UPDATE dogs
                SET Dog_Thing = "'.$favorite.'"
                WHERE Dog_Name = "'.$dog.'" OR Dog_Name = "'.$newname.'";');
                $query->execute();
            }
            if(isset($_POST['Gender']) && $_POST['Gender'] != ''){
                $gender = $_POST['Gender'];
                $query = $pdo->prepare('UPDATE dogs
                SET Dog_Gender = "'.$gender.'"
                WHERE Dog_Name = "'.$dog.'" OR Dog_Name = "'.$newname.'";');
                $query->execute();
            }
            $owner = $_POST['Owner'];
            $query = $pdo->prepare('SELECT * FROM owner WHERE Owner_Name = "'.$owner.'";');
            $query->execute();
            $row = $query->fetch(PDO::FETCH_ASSOC);
            $query=$pdo->prepare('UPDATE dogs
            SET Owner_ID = '.$row['Owner_ID'].'
            WHERE Dog_Name = "'.$dog.'" OR Dog_Name = "'.$newname.'";');
            $query->execute();
           header('Location: admin.php');
        }
          $query = $pdo->prepare('SELECT * FROM dogs;');
          $query->execute();
          foreach($query as $name){
            $doglist .= '<option value="'.$name['Dog_Name']. '">' .$name['Dog_Name']. "</option>";
          }
          $query = $pdo->prepare('SELECT * FROM Owner;');
          $query->execute();
          foreach($query as $name){
            $options .= '<option value="'.$name['Owner_Name']. '">' .$name['Owner_Name']. "</option>";
          }
          $pdo=null;
    
?>
    <!DOCTYPE html>
    <html lang="en">
    
    <head>
    <title>Dog Zone: Edit Dogs</title>
    <meta charset="utf-8">
    </head>
    
    <body class="w3-yellow">
        <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <p>
        <h1 class="w3-center w3-text-blue w3-yellow"><b>Edit Dogs</b></h1>
    </p>
    <p>
  <?php if (isset($error)) { ?>
    <!-- If there is an error, display it -->
    <p class="w3-center w3-text-red"><?php //echo $error; ?></p>
  <?php } ?>
  </p>
    <form class="w3-center" method="POST">
        <div>
    <p class="w3-container"><label for="User" class="w3-center w3-text-blue w3-Large">Dog to Edit </label><select class="w3-select" name="User">
        <?php
        echo $doglist;
        ?>
        
    </select></p> </div>
    <p><label for="newname"class="w3-center w3-text-blue">New Name:</label><input type="textbox" name="newname" id="name"></p>
    <p><label for="age" class="w3-center w3-text-blue">New Age:</label><input type="textbox" name="age" id="age"></p>
    <p><label for="Breed" class="w3-center w3-text-blue">New Breed:</label><input type="textbox" name="Breed" id="breed"></p>
    <p><label for="favorite" class="w3-center w3-text-blue">New Favorite Thing:</label><input type="textbox" name="favorite" id="fav"></p>
    <p><label for="gender" class="w3-center w3-text-blue">New Gender:</label><input type="textbox" name="gender" id="gender"></p>
    <div>
    <label for="GoodBoy"class="w3-center w3-text-blue">Good Boy </label><input type="radio" name="Gender" value='GoodBoy'>
    </div>
    <div>
    <label for="Goodgirl"class="w3-center w3-text-blue">Good Girl </label><input type="radio" name="Gender" value='GoodGirl'>
    </div>
    <div>
    <p class="w3-container"><label for="Owner" class="w3-center w3-text-blue w3-Large">New Owner </label><select class="w3-select" name="Owner">
        <?php
        echo $options;
        ?>
        
    </select></p> </div>
    <p><button name="submit" value="edits" class="w3-button w3-black">Submit Edits</button></p>
    </form>
    <footer class="w3-panel w3-center w3-small w3-text-gray w3-bottom">
        &copy; 2022 Caleb Sutton
    </footer>
    
    
    </body>
    
    </html>