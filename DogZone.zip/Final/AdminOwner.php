<!-- filename: AdminOwner.php
    Author: Caleb Sutton -->

    <?php
        session_start();
        if(!isset($_SESSION['username'])){
            header('Location: notloggedin.php');
        }
        else{
            $username = $_SESSION['username'];
            if ($username != 'admin'){
                header("Location: Welcome.php");
            }
    
        }
    ?>


<!DOCTYPE html>
    <html lang="en">
    
    <head>
    <title>Dog Zone: Admin</title>
    <meta charset="utf-8">
    </head>
    <body class="w3-yellow">
        <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <p>
        <h1 class="w3-center w3-text-blue w3-yellow"><b>Edit Owner</b></h1>
    </p>
    <section>
    <form action='EditOwner.php'><button name='editowner' class="w3-button w3-blue" value = 'newDog'>Edit Owner</button></form>
    <form action='DeleteOwner.php'><button name='deleteowner' class="w3-button w3-blue" value = 'newDog'>Delete Owner</button></form>
    <form action='CreateOwner.php'><button name='createowner' class="w3-button w3-blue" value = 'newDog'>Create Owner</button></form>

</html>