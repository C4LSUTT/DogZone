<!-- filename: Signup.php
    Author: Caleb Sutton -->
    <?php
session_start();
// Check if the form has been submitted
error_reporting(E_ALL);
ini_set('display_errors', '1');

if (isset($_POST['submit'])) {
  // Get the form data
  $username = $_POST['username'];
  $password = $_POST['password'];
  


  // Validate the form data
  if ($username == '' ||  $password == '') {
    // If any of the fields are empty, display an error message
    $error = 'All fields are required.';
  }

  try {
    $pdo = new PDO("mysql:host=localhost;port=8889;dbname=project", "root", "root");
    // set the PDO error mode to exception
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    //echo "Connected successfully";
  } 
  catch(PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
  }

  // Check if the username and password are already in use
  $query = $pdo->prepare('SELECT * FROM registration WHERE username = "'.$username.'";');
  $query->execute();

   //If the query returns a valid result, the username or password is already in use
  if ($query->rowCount() > 0) {
    $error = 'The username is already in use. Please choose a different username or password';
  }
    else{
      $passwordHash = password_hash($password, PASSWORD_BCRYPT);
    // If the username and password are not in use, create a new user
    $query = $pdo->prepare('INSERT INTO registration (username, password) VALUES ("'.$username.'","'.$passwordHash.'");');
    $query->execute();
    $_SESSION['username'] = $username;
    // Redirect the user to the login page
    header('Location: welcome.php');

    // Close the database connection
    $pdo = null;
    }
}

?>
    <!DOCTYPE html>
    <html lang="en">
    
    <head>
    <title>Dog Zone: Sign Up</title>
    <meta charset="utf-8">
    </head>
    
    <body class="w3-yellow">
        <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <p>
        <h1 class="w3-center w3-text-blue w3-yellow"><b>Create an Account</b></h1>
    </p>
    <section>
        <header>
            <h2 class="w3-center w3-text-blue">Fill out the information below to create an account<br><h2>
        </header>
        <form action="" method="post">
  <?php if (isset($error)) { ?>
    <!-- If there is an error, display it -->
    <p class="w3-center w3-text-red"><?php //echo $error; ?></p>
  <?php } ?>
  

</form>
    <form class="w3-auto w3-center"action="notloggedin.php">
        <button class="w3-button w3-black">already have an account? Log in here!</button>       
    </form>
    <form class= "w3-center" method="POST">
            <p><label for="username" class="w3-center w3-text-blue">Username:</label><input type="textbox" name="username" id="username" placeholder="doglover28"></p>
            <p><label for="password"class="w3-center w3-text-blue">Password:</label><input type="password" name="password" id="password"></p>
            <p><button name="submit" value="Register" class="w3-button w3-black">Register</button></p>
    </form>
    </section>
    
    <footer class="w3-panel w3-center w3-small w3-text-gray w3-bottom">
        &copy; 2022 Caleb Sutton
    </footer>
    
    
    </body>
    
    </html>