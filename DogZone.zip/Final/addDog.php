<!-- filename: addDog.php
    Author: Caleb Sutton -->
<?php
    session_start();
    error_reporting(E_ALL);
ini_set('display_errors', '1');

if(!isset($_SESSION['username'])){
    header('Location: notloggedin.php');
}
else{
    $options = '';
    $username = $_SESSION['username'];
    if ($username == 'admin'){
        header("Location: admin.php");
    }
    else{
        try {
            $pdo = new PDO("mysql:host=localhost;port=8889;dbname=project", "root", "root");
            // set the PDO error mode to exception
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            //echo "Connected successfully";
          } 
          catch(PDOException $e) {
            echo "Connection failed: " . $e->getMessage();
          }
          $query = $pdo->prepare('SELECT * 
          FROM registration 
          WHERE username = "'.$username.'";');
          $query->execute();
          $row = $query->fetch(PDO::FETCH_ASSOC);

          $query = $pdo->prepare('SELECT * FROM Owner WHERE id = "'.$row['id'].'";');
          $query->execute();
          foreach($query as $name){
            $options .= '<option value="'.$name['Owner_Name']. '">' .$name['Owner_Name']. "</option>";
          }

    }
    if(isset($_POST['submit'])){
        $owner = $_POST['owner'];
        $name = $_POST['dogName'];
        $age = $_POST['dogAge'];
        $breed = $_POST['dogBreed'];
        $thing = $_POST['favorite'];
        if($_POST['Gender'] == 'GoodBoy'){
            $gender = 'Good Boy';
        }
        elseif($_POST['Gender' == 'GoodGirl']){
            $gender = 'Good Girl';
        }

        if($name = '' || $age = '' || $breed = '' || $gender = '' || $owner = '' || $thing = ''){
            $error = 'all fields must be filled out';
        }
        
        $owner = $_POST['owner'];

        $query = $pdo->prepare('SELECT * 
        FROM owner 
        WHERE Owner_Name = "'.$owner.'";');
        $query->execute();
        $row = $query->fetch(PDO::FETCH_ASSOC);
        $ownerid = $row['Owner_ID'];


        $name = $_POST['dogName'];
        $age = $_POST['dogAge'];
        $breed = $_POST['dogBreed'];
        $thing = $_POST['favorite'];
        if($_POST['Gender'] == 'GoodBoy'){
            $gender = 'Good Boy';
        }
        elseif($_POST['Gender' == 'GoodGirl']){
            $gender = 'Good Girl';
        }
        
        $query = $pdo->prepare('INSERT INTO Dogs (Dog_Name, Dog_Age, Dog_Breed, Dog_Thing, Dog_Gender, Owner_ID)
        VALUES("'.$name.'","'.$age.'","'.$breed.'","'.$thing.'","'.$gender.'",'.$ownerid.');');
        $query->execute();
        header("Location: Welcome.php");
    }
}
?>
<!DOCTYPE html>
    <html lang="en">
    
    <head>
    <title>Dog Zone: Add a Dog</title>
    <meta charset="utf-8">
    </head>
    
    <body class="w3-yellow">
        <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <p>
        <h1 class="w3-center w3-text-blue w3-yellow"><b>Add a Dog</b></h1>
    </p>
    <section>
    <form class="w3-center" method="POST">
    <p><label for="dogName" class="w3-center w3-text-blue">Name:</label><input type="textbox" name="dogName" id="dogName"></p>
    <p><label for="dogAge"class="w3-center w3-text-blue">Age:</label><input type="number" name="dogAge" id="dogAge"></p>
    <p><label for="dogBreed"class="w3-center w3-text-blue">Breed:</label><input type="textbox" name="dogBreed" id="dogBreed"></p>
    <p><label for="favorite" class="w3-center w3-text-blue">Favorite Thing:</label><input type="textbox" name="favorite" id="favorite"></p>
    <div>
    <label for="GoodBoy"class="w3-center w3-text-blue">Good Boy </label><input type="radio" name="Gender" value='GoodBoy' checked>
    </div>
    <div>
    <label for="Goodgirl"class="w3-center w3-text-blue">Good Girl </label><input type="radio" name="Gender" value='GoodGirl'>
    </div>
    <select name="owner" id="owner">
    <?php
    echo $options;
    ?>
    </select>

    <p><button name="submit" value="Register" class="w3-button w3-black">Add Dog</button></p>
    </form>
</section>
    <footer class="w3-panel w3-center w3-small w3-text-gray w3-bottom">
        &copy; 2022 Caleb Sutton
    </footer>
    
    
    </body>
    
    </html>