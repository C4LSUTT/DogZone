<!-- filename: admin.php
    Author: Caleb Sutton -->
    <?php
session_start();
if(!isset($_SESSION['username'])){
    header('Location: notloggedin.php');
}
else{
    $username = $_SESSION['username'];
    if ($username != 'admin'){
        header("Location: Welcome.php");
    }

    $tabler = '<tr><th>Name</th><th>Age</th><th>Favorite Thing</th></tr>';
    $tablel = '<tr><th>Name</th><th>Age</th><th>Breed</th><th>Favorite Thing</th><th>Gender</th><th>Owner</th></tr>';
    try {
        $pdo = new PDO("mysql:host=localhost;port=8889;dbname=project", "root", "root");
        // set the PDO error mode to exception
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        //echo "Connected successfully";
      } 
      catch(PDOException $e) {
        echo "Connection failed: " . $e->getMessage();
      }
      $query = $pdo->prepare('SELECT * 
      FROM registration 
      WHERE username = "'.$username.'";');
      $query->execute();
      $row = $query->fetch(PDO::FETCH_ASSOC);

      $query = $pdo->prepare('SELECT * FROM Owner;');
      $query->execute();
      foreach($query as $name){
        $tabler .= '<tr><td>'.$name['Owner_Name'].'</td><td>'.$name['Owner_Age'].'</td><td>'.$name['Owner_Thing'].'</td></tr>';
        $owner = $name['Owner_Name'];
        $newq = $pdo->prepare('SELECT * FROM Dogs WHERE Owner_ID = '.$name['Owner_ID'].';');
        $newq->execute();
        foreach($newq as $newname){
            $tablel .= '<tr><td>'.$newname['Dog_Name'].'</td><td>'.$newname['Dog_Age'].'</td><td>'.$newname['Dog_Breed'].'</td><td>'.$newname['Dog_Thing'].'</td><td>'.$newname['Dog_Gender'].'</td><td>'.$owner.'</tr>';
        }
      }
    }

?>









<!DOCTYPE html>
    <html lang="en">
    
    <head>
    <title>Dog Zone: Admin</title>
    <meta charset="utf-8">
    </head>
    
    <body class="w3-yellow">
        <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <p>
        <h1 class="w3-center w3-text-blue w3-yellow"><b>Welcome <?php echo $username ?></b></h1>
    </p>
    <section>

    </section>
    <section class="w3-left w3-container" method="POST">
    <form action='AdminUser.php'><button name='newDog' class="w3-button w3-blue" value = 'newDog'>Edit Users</button></form>
    <form action='AdminDog.php'><button name='newDog' class="w3-button w3-blue" value = 'newDog'>Edit Dogs</button></form>
    <div class="w3-center w3-large w3-container w3-blue" >
       ALL DOGS
    </div>
    <div>
        <table class= "w3-table w3-border w3-left align w3-blue">
            <?php echo $tablel;?>
        </table>
    </div>
    </section>

    <section class="w3-right w3-container" method="POST">
    <form action="AdminOwner.php" ><button name='newOwner' class="w3-button w3-blue" value = 'newOwner'>Edit Owners</button></form>
    <div class="w3-center w3-large w3-container w3-blue" >
       ALL OWNERS
    </div>
    <div>
        <table class= "w3-table w3-border w3-left align w3-blue">
            <?php echo $tabler;?>
        </table>
    </div>
    </section>
    
    <footer class="w3-panel w3-center w3-small w3-text-gray w3-bottom">
        &copy; 2022 Caleb Sutton
    </footer>
    
    
    </body>
    
    </html>