<!-- filename: notloggedin.php
    Author: Caleb Sutton -->
    <?php
session_start();
// Check if the form has been submitted
error_reporting(E_ALL);
ini_set('display_errors', '1');


if (isset($_POST['submit'])) {
  // Get the form data
  $username = $_POST['username'];
  $password = $_POST['password'];

  // Validate the form data
  if ($username == '' ||  $password == '') {
    // If any of the fields are empty, display an error message
    $error = 'All fields are required.';
  }

  try {
    $pdo = new PDO("mysql:host=localhost;port=8889;dbname=project", "root", "root");
    // set the PDO error mode to exception
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    //echo "Connected successfully";
  } 
  catch(PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
  }
  // Check if the username and password are already in use
  $query = $pdo->prepare('SELECT * 
  FROM registration 
  WHERE username = "'.$username.'";');
  $query->execute();
  $row = $query->fetch(PDO::FETCH_ASSOC);
  if ($query->rowCount() == 0) {
    $error = 'Invalid username';
  }
  if(password_verify($password, $row['password'])){
    $_SESSION['username'] = $username;
    header('Location: Welcome.php');
  }
  else{
    $error = 'Invalid password';
  }
}

?>



    <!DOCTYPE html>
    <html lang="en">
    
    
    <head>
    <title>Dog Zone: Log In</title>
    <meta charset="utf-8">
    </head>
    
    <body class="w3-yellow">
        <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <p>
        <h1 class="w3-center w3-text-blue w3-yellow"><b>Welcome to Dog Zone!</b></h1>
    </p>
    <section>
        <header>
            <h2 class="w3-center w3-text-blue">It appears you havent logged in yet or made an account<br><h2>
        </header>
    
        <article>
        <p class="w3-center w3-text-blue">Please log in or sign up to see all of our furry friends!</p>
        </article>
        <form action="" method="post">
  <?php if (isset($error)) { ?>
    <!-- If there is an error, display it -->
    <p class="w3-center w3-text-red"><?php //echo $error; ?></p>
  <?php } ?>
</form>
    <form class="w3-cell-middle w3-auto w3-center" action="signup.php">
        <button class="w3-button w3-black" >don't have an account? Sign up here!</button>       
    </form>
    <form class= "w3-center" method="POST">
    <p><label for="username" class="w3-center w3-text-blue">Username:</label><input type="textbox" name="username" id="username" placeholder="doglover28"></p>
            <p><label for="password"class="w3-center w3-text-blue">Password:</label><input type="password" name="password" id="password"></p>
            <p><button name='submit' class="w3-button w3-black" value = 'login'>Login</button></p>
    </form>
    </section>
    
    <footer class="w3-panel w3-center w3-small w3-text-gray w3-bottom">
        &copy; 2022 Caleb Sutton
    </footer>
    
    
    </body>
    
    </html>