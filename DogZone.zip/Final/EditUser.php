<!-- filename: EditUser.php
    Author: Caleb Sutton -->
    <?php
    session_start();
    error_reporting(E_ALL);
ini_set('display_errors', '1');

if(!isset($_SESSION['username'])){
    header('Location: notloggedin.php');
}
    $userlist = '';
    $username = $_SESSION['username'];
    if ($username != 'admin'){
        header("Location: Welcome.php");
    }

        try {
            $pdo = new PDO("mysql:host=localhost;port=8889;dbname=project", "root", "root");
            // set the PDO error mode to exception
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            //echo "Connected successfully";
          } 
          catch(PDOException $e) {
            echo "Connection failed: " . $e->getMessage();
          }
          if(isset($_POST['submit'])){
            $user = $_POST['User'];
            if(isset($_POST['newuser']) && $_POST['newuser'] != ''){
                $newuser = $_POST['newuser'];
                $query = $pdo->prepare('UPDATE registration
                SET username = "'.$newuser.'"
                WHERE username = "'.$user.'";');
                $query->execute();
            }
            if(isset($_POST['pass']) && $_POST['pass'] != ''){
                $newpass = $_POST['pass'];
                $newpasshash = password_hash($newpass, PASSWORD_BCRYPT);
                $query = $pdo->prepare('UPDATE registration
                SET password = "'.$newpasshash.'"
                WHERE username = "'.$user.'" OR username = "'.$newuser.'";');
                $query->execute();
            }
           header('Location: admin.php');
        }
          $query = $pdo->prepare('SELECT * FROM registration;');
          $query->execute();
          foreach($query as $name){
            $userlist .= '<option value="'.$name['username']. '">' .$name['username']. "</option>";
          }
          $pdo=null;
    
?>
    <!DOCTYPE html>
    <html lang="en">
    
    <head>
    <title>Dog Zone: Add an Owner</title>
    <meta charset="utf-8">
    </head>
    
    <body class="w3-yellow">
        <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <p>
        <h1 class="w3-center w3-text-blue w3-yellow"><b>Edit Users</b></h1>
    </p>
    <p>
  <?php if (isset($error)) { ?>
    <!-- If there is an error, display it -->
    <p class="w3-center w3-text-red"><?php //echo $error; ?></p>
  <?php } ?>
  </p>
    <form class="w3-center" method="POST">
        <div>
    <p class="w3-container"><label for="User" class="w3-center w3-text-blue w3-Large">User to Edit </label><select class="w3-select" name="User">
        <?php
        echo $userlist;
        ?>
        
    </select></p> </div>
    <p><label for="newuser"class="w3-center w3-text-blue">New Username:</label><input type="textbox" name="newuser" id="user"></p>
    <p><label for="pass" class="w3-center w3-text-blue">New Password:</label><input type="textbox" name="pass" id="pass"></p>
    <p><button name="submit" value="AddOwner" class="w3-button w3-black">Submit Edits</button></p>
    </form>
    <footer class="w3-panel w3-center w3-small w3-text-gray w3-bottom">
        &copy; 2022 Caleb Sutton
    </footer>
    
    
    </body>
    
    </html>